# PHP-URL-Shortener
Build a URL shortener with PHP.

source code of the video tutorial "PHP URL Shortener" by phpacademy

YouTube link:
https://www.youtube.com/playlist?list=PLfdtiltiRHWHrqrITYaVHB_3oAaS6PoIl
